﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoLP2
{
    public class Pessoa
    {
        public string Nomee;
        public Pessoa(string nome) { Nomee = nome; }

        public string Nome(string nome)
        {
            if (string.IsNullOrEmpty(nome))
            {
                throw new NullReferenceException("O nome não pode ser nulo! Tente novamente.");
            }
            return nome;

        }


    }
    internal class Program
    {
        public static int Num(int num)
        {
            if (num < 0 || num > 11)
            {
                throw new IndexOutOfRangeException("Índice não pertencente a lista, tente novamente.");
            }
            return num;
        }
        public static byte Byt(byte byt)
        {
            if (byt < 0 || byt>255)
            {
                throw new OverflowException("Valor era muito grande ou muito pequeno para um byte não atribuído, tente novamente.");
            }
            return byt;
        }

        static void Main(string[] args)
        {
            int num;

            string[] array = new string[12 - 1];
            Console.WriteLine(" 0 - Preto");
            Console.WriteLine(" 1 - Marrom");
            Console.WriteLine(" 2 - Marrom");
            Console.WriteLine(" 3 - Laranja");
            Console.WriteLine(" 4 - Amarelo");
            Console.WriteLine(" 5 - Verde Alface");
            Console.WriteLine(" 6 - Verde Folha");
            Console.WriteLine(" 7 - Azul Claro");
            Console.WriteLine(" 8 - Azul Escuro");
            Console.WriteLine(" 9 - Violeta");
            Console.WriteLine("10 - Rosa ");
            Console.WriteLine("11 - Branco");

            Console.WriteLine("\nEscolha uma cor: ");
            num = int.Parse(Console.ReadLine());

            try
            {
                Num(num);
                Console.Clear();

            }
            catch (Exception a)
            {
                while (num < 0 || num > 11)
                {
                    Console.WriteLine(a.GetType().Name);
                    Console.WriteLine($"Erro: {a.Message}");
                    Console.WriteLine("\nEscolha uma cor: ");
                    num = int.Parse(Console.ReadLine());
                    
                    
                }

            }
            string nome;


            Console.WriteLine("Digite um nome:");
            nome = Console.ReadLine();
            Pessoa pessoa = new Pessoa(nome);
            try
            {
                pessoa.Nome(nome);
                Console.Clear();
               
            }
            catch (Exception b)
            {
                while (string.IsNullOrEmpty(nome))
                {
                    Console.WriteLine(b.GetType().Name);
                    Console.WriteLine($"Erro: {b.Message}");
                    Console.WriteLine("\nDigite um nome:");
                    nome = Console.ReadLine();
                    
                  
                }
            }
            byte byt;
            Console.WriteLine("Digite um número entre 0 e 255:");
            byt = byte.Parse(Console.ReadLine());
            try
            {
                Byt(byt);
                Console.Clear();

            }
            catch (Exception c)
            {
                while (byt < 0 || byt > 255)
                {
                    Console.WriteLine(c.GetType().Name);
                    Console.WriteLine($"Erro: {c.Message}");
                    Console.WriteLine("Digite um número entre 0 e 255:");
                    byt = byte.Parse(Console.ReadLine());
                    

                }
            }
        }

     }

}
